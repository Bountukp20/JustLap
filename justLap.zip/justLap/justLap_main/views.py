from .models import *
from justLap_main.forms import UserImage
from django.contrib import messages
from django.shortcuts import render, get_object_or_404, redirect
from django.views import View
from django.views.generic import ListView, DetailView
from django.utils import timezone
from django.db.models import Q
from django.http import HttpResponseRedirect
from django.http import HttpResponse
from django.db.models import Q
from django.contrib.auth.models import User
from django.contrib import auth
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required
import random
from django.db.models import Subquery, OuterRef

# Create your views here

def faq(request):
    products = Faq.objects.all()
    context = {}
    if Faq.objects.all():
        context["has_item"] = True
    context["products"] = products
    return render(request, 'justLap_main/FAQ.html', context)

def about(request):
    about_content = About.objects.all()
    context = {}
    context["about_content"] = about_content
    return render(request, 'justLap_main/about.html', context)

def reviews(request):
    main_store = About()
    main_store.user = request.user
    main_store.name = request.POST.get('name')
    main_store.email = request.POST.get('email')
    main_store.message = request.POST.get('message')
    main_store.user_image = request.POST.get('user_image')
    main_store.save()
    return redirect("thankyou")

def index(request):
    products = Product.objects.all()[0:6]
    context = {}
    # product_item = About.objects.filter(user=request.user)
    # for product in product_item:
    #     product.user_image = request.POST.get('user_image')
    #     product.save()
    # context["product_item"] = product_item
    # store = Store.objects.filter(user=request.user).count()
    # if store is not None:
    #     context["store"] = store
    #     context["has_item"] = True
    # else:
    #     context["has_item"] = False
    context["products"] = products
    return render(request, 'justLap_main/index.html', context)

def pay_on_delivery(request):
    stored_items = BookedList.objects.filter(user=request.user).count()
    
    context = {}
    if stored_items == 0:
        context["product_item"] = []
        context["has_item"] = False
    else:
        product_item = BookedList.objects.all()
        
        context["product_item"] = product_item
        context["has_item"] = True
    return render(request, 'justLap_main/pay_on_delivery.html', context)

def thankyou(request):  
    return render(request, 'justLap_main/ThankYou.html')

@login_required(login_url='login')
def order_request(request):
    stored_items = Store.objects.filter(user=request.user).count()
    
    context = {}
    if stored_items == 0:
        context["product_item"] = []
        context["has_item"] = False
    else:
        product_item = Store.objects.all()
        
        context["product_item"] = product_item
        context["has_item"] = True
    return render(request, 'justLap_main/order_item.html', context)

# class ProductView(DetailView):
#     model = Product
#     template_name = "justLap_main/products.html"
# def is_stored_items(self, request):
#     stored_items = request.session.get("stored_items")
#     product_item = Product.objects.filter(id__in=stored_items)
#     if stored_items is not None:
#         is_saved_for_view = product_item in stored_items
#     else:
#         is_saved_for_view = False
        
#     return is_saved_for_view
@login_required(login_url='login')
def view_order(request):
    view = Booked.objects.filter(user=request.user)
    if view:
        context["has_item"] = True
    else:
        context["has_item"] = False
    context = {
        "view": view,
    }
    return render(request, 'justLap_main/order.html', context)

@login_required(login_url='login')
def products(request):
    # stored_items = request.session.get("stored_items")
    # product_item = Product.objects.filter(id__in=stored_items)
    store = Store.objects.filter(user=request.user).count()
    products = Product.objects.all()
    if 'query' in request.GET:
        query = request.GET['query']
        multiple_q = Q(Q(product_name__icontains=query) | Q(description__icontains=query) | Q(price__icontains=query))
        products = Product.objects.filter(multiple_q)
        # products = Product.objects.filter(product_name__icontains=query)
    # if 'query' not in request.GET:
    #     return HttpResponse("Sorry, but we found nothing")
    else:
        products = Product.objects.all()
        
    context = {
        "products": products,
        "store": store,
        # "product_item": product_item,
        # "saved_for_view": self.is_stored_items(request),
    }
    return render(request, 'justLap_main/products.html', context)
    
@login_required(login_url='login')
def get(request):
    stored_items = Store.objects.all()
    # product = Product.objects.all()
    
    # Store.objects.filter(
    #     pk__in = Store.name('name').distinct().annotate(
    #         pk = Subquery(
    #             Store.objects.filter(
    #                 name = OuterRef('name')
    #             )
    #             .order_by("pk")
    #             .values("pk")[:1]
    #         )
    #         .name("pk", flat=True)
    #     )
    # )
    
    context = {}
    if stored_items is None or len(stored_items) == 0:
        context["has_item"] = False
    else:
        context["has_item"] = True
    store = Store.objects.filter(user=request.user)
    context["store"] = store
    
    total_prices = sum(int(product.product_price) for product in store)
    context["total_prices"] = total_prices
    
    return render(request, 'justLap_main/stored-items.html', context)

# def increment(request):
#     stored_items = request.session.get("stored_items")
    
#     if stored_items is None:
#         stored_items = []
        
#     product_id = int(request.POST["product_id"])
        
#     if product_id not in stored_items:
#         stored_items.append(product_id)
#         request.session["stored_items"] = stored_items
#     return HttpResponseRedirect("get")

def post(request):
    # if request.method == 'POST':
    stored_item = request.session.get("stored_items")
    
    if stored_item is None:
        stored_item = []
        
    product_id = int(request.POST["product_id"])
        
    if product_id not in stored_item:
        try:
            # stored_item.append(product_id)


            # product_item = Product.objects.filter(product_id)
            # for product in product_item:
            main_store = Store()
            main_store.user = request.user
            main_store.id = request.POST.get('product_id')
            main_store.product_image = request.POST.get('product_image')
            main_store.name = request.POST.get('product_name')
            main_store.product_price = request.POST.get('product_price')
            main_store.detail = request.POST.get('description')
            main_store.product_discount = request.POST.get('product_discount_price')
            main_store.save()
            # request.session["stored_items"] = stored_item
        except:
            return redirect(request.META['HTTP_REFERER'])
    # else:
    #     stored_item.remove(product_id)
        # stored_items.delete(id=product_id)
        # records = Store.objects.all()
        # for record in records:
        # old_record = Store.objects.filter(id__in=stored_items)
        # old_record.delete()

    request.session["stored_items"] = stored_item
    print(stored_item)
    return redirect(request.META['HTTP_REFERER'])

# def delete_item(request):
#     return HttpResponseRedirect("product_delete")

def product_delete_view(request, id):
    # if request.method == 'POST':
    obj = get_object_or_404(Store, pk=id)
    obj.delete()
    context = {
        'obj': obj
    }
    return render(request, 'justLap_main/Confirm_delete.html', context)

def delete_session(request):
    
    # stored_items = request.session.get("stored_items")
    # del request.session["stored_items"]
    main_store = Store.objects.filter(user=request.user)
    main_store.delete()
    records = Store.objects.all()
    index = 1
    for record in records:
        old_record = Store.objects.get(id=record.id)
        record.id = index
        record.save()
        old_record.delete()
        index = index + 1
    # print(stored_items)
    return HttpResponseRedirect("products/get")

def sign_up(request):
    if request.method == "POST":
        if request.POST['password1'] == request.POST['password2']:
            try:
                User.objects.get(username = request.POST['username'])
                return render (request,'justLap_main/registration/sign up.html', {'error':'Username is already taken!'})
            except User.DoesNotExist:
                user = User.objects.create_user(request.POST['username'],password=request.POST['password1'])
                auth.login(request,user)
                return redirect('login')
        else:
            return render (request,'justLap_main/registration/sign up.html', {'error':'Password does not match!'})
    else:
        return render(request,'justLap_main/registration/sign up.html')

def login(request):
    if request.method == 'POST':
        user = auth.authenticate(username=request.POST['username'],password = request.POST['password'])
        if user is not None:
            auth.login(request,user)
            return redirect('/')
        else:
            return render (request,'justLap_main/registration/login.html', {'error':'Username or password is incorrect!'})
    else:
        return render(request,'justLap_main/registration/login.html')

def logout_request(request):
    logout(request)
    return redirect('/')

def place_order(request):
    # stored_item = request.session.get("stored_items")
    # stored_items = Session_id.objects.filter(id__in=stored_item)
    products = Product.objects.filter(id__in=Store.objects.all())
    if request.method == 'POST':
        for product in products:
            if product.quantity >= 1:
                neworder = BookedList()
                neworder.user = request.user
                neworder.fname = request.POST.get('fname')
                neworder.lname = request.POST.get('lname')
                neworder.email = request.POST.get('email')
                neworder.address = request.POST.get('address')
                neworder.city = request.POST.get('city')
                neworder.state = request.POST.get('state')
                neworder.country = request.POST.get('country')
                neworder.pin_code = request.POST.get('pin_code')
                neworder.payment_mode = request.POST.get('payment_mode')
                neworder.message = request.POST.get('message')
                
                trackno = 'JustLap'+str(random.randint(1111111,9999999))
                while BookedList.objects.filter(tracking_no=trackno) is None:
                    trackno = 'JustLap'+str(random.randint(1111111,9999999))

                neworder.tracking_no = trackno
                neworder.save()
            
                messages.success(request, "Your order has been placed successfully")
                
                product.quantity = product.quantity - 1
                
                product.save()
                
            if product.quantity < 1:
                product.delete()
        bookList = BookedList.objects.all()
        all_product = Store.objects.filter(user=request.user)
        if bookList is not None:
            for product in all_product:
                main_store = Booked()
                main_store.user = request.user
                main_store.product_image = product.product_image
                main_store.name = product.name
                main_store.product_price = product.product_price
                main_store.detail = product.detail
                main_store.product_discount = product.product_discount
                main_store.save()
        all_store = Store.objects.filter(user=request.user)
        all_store.delete()
        # stored_items = request.session.get("stored_items")
        # del request.session["stored_items"]
    return redirect('pay_on_delivery')

# def add_to_cart(request, product_id, quantity): 
#     item = get_object_or_404(Product, pk = pk )
#     order_item, created = Cart.objects.get_or_create(
#         item=item,
#         user = request.user,
#         ordered = False
#     )
#     order_qs = Order.objects.filter(user=request.user, ordered= False)

#     if order_qs.exists() :
#         order = order_qs[0]
        
#         if order.items.filter(item__pk = item).exists() :
#             order_item.quantity += 1
#             order_item.save()
#             messages.info(request, "Added quantity Item")
#             return redirect("justLap_main:products")
#         else:
#             order.items.add(order_item)
#             messages.info(request, "Item added to your cart")
#             return redirect("justLap_main:products")
#     else:
#         ordered_date = timezone.now()
#         order = Order.objects.create(user=request.user, ordered_date = ordered_date)
#         order.items.add(order_item)
#         messages.info(request, "Item added to your cart")
#         return redirect("justLap_main:products")

# def remove_from_cart(request, pk):
#     item = get_object_or_404(Product, pk=pk )
#     order_qs = Order.objects.filter(
#         user=request.user, 
#         ordered=False
#     )
#     if order_qs.exists():
#         order = order_qs[0]
#         if order.items.filter(item__pk=item.pk).exists():
#             order_item = Cart.objects.filter(
#                 item=item,
#                 user=request.user,
#                 ordered=False
#             )[0]
#             order_item.delete()
#             messages.info(request, "Item \""+order_item.item.product_name+"\" remove from your cart")
#             return redirect("justLap_main:products")
#         else:
#             messages.info(request, "This Item not in your cart")
#             return redirect("justLap_main:products", pk=pk)
#     else:
#         #add message doesnt have order
#         messages.info(request, "You do not have an Order")
#         return redirect("justLap_main:products", pk = pk)

# def add_to_cart(request, pk) :
#     item = get_object_or_404(Product, pk=pk )
#     order_item, created = OrderItem.objects.get_or_create(
#         item=item,
#         user = request.user,
#         ordered = False
#     )
#     order_qs = Order.objects.filter(user=request.user, ordered= False)

#     if order_qs.exists() :
#         order = order_qs[0]
        
#         if order.items.filter(item__pk=item.pk).exists() :
#             order_item.quantity += 1
#             order_item.save()
#             messages.info(request, "Added quantity Item")
#             return redirect("justLap_main:products", pk=pk)
#         else:
#             order.items.add(order_item)
#             messages.info(request, "Item added to your cart")
#             return redirect("justLap_main:products", pk=pk)
#     else:
#         ordered_date = timezone.now()
#         order = Order.objects.create(user=request.user, ordered_date = ordered_date)
#         order.items.add(order_item)
#         messages.info(request, "Item added to your cart")
#         return redirect("justLap_main:products", pk = pk)

# def remove_from_cart(request, pk):
#     item = get_object_or_404(Product, pk=pk )
#     order_qs = Order.objects.filter(
#         user=request.user,
#         ordered=False
#     )
#     if order_qs.exists():
#         order = order_qs[0]
#         if order.items.filter(item__pk=item.pk).exists():
#             order_item = OrderItem.objects.filter(
#                 item=item,
#                 user=request.user,
#                 ordered=False
#             )[0]
#             order_item.delete()
#             messages.info(request, "Product \""+order_item.item.product_name+"\" was removed from your cart")
#             return redirect("justLap_main:products")
#         else:
#             messages.info(request, "This Item not in your cart")
#             return redirect("justLap_main:products", pk=pk)
#     else:
#         # add message doesnt have order
#         messages.info(request, "You do not have an Order")
#         return redirect("justLap_main:products", pk = pk)