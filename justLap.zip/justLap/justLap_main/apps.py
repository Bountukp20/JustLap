from django.apps import AppConfig


class JustlapMainConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'justLap_main'
