console.log('working')
if(localStorage.getItem('cart') == null)
{
var cart={};
}
else{
cart= JSON.parse(localstorage.getItem('cart'));
}
//jQuery starts here//
$('.cart').click(function(){

console.log('clicked');
});
