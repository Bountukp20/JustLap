from django.contrib import admin

# Register your models here.
from .models import *

admin.site.register(Faq)
admin.site.register(Product)
admin.site.register(BookedList)
# admin.site.register(OrderItems)
admin.site.register(About)
admin.site.register(Booked)
admin.site.register(Store)