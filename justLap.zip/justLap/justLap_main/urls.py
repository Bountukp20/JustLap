from django.urls import path
from .views import (
    # remove_from_cart,
    # add,
    get,
    post,
    delete_session,
    sign_up,
    login,
    logout_request,
    place_order,
    order_request,
    about,
    view_order,
    product_delete_view,
    faq,
    reviews,
    # reviews,faq,
    # reviews,faq,
    thankyou,
    pay_on_delivery,
)
from . import views

# app_name = 'justLap_main'

urlpatterns = [
    path("sign_up/", sign_up, name="sign_up"),
    path("", views.index, name="starting-page"),
    path('products/', views.products, name='products'),
    path("add-cart", post, name="add-cart"),
    path("delete", delete_session, name="delete"),
    path("products/get", get, name="get"),
    path("login/", login, name="login"),
    path("logout_request/", logout_request, name="logout_request"),
    path('place-order', views.place_order, name="place-order"),path("order_request/", order_request, name="order_request"),
    path("about", about, name="about"),
    path("view_order", view_order, name="view_order"),
    path('<int:id>', views.product_delete_view, name='product_delete_view'),
    path("faq", faq, name="faq"),
    path('reviews', reviews, name='reviews'),
    path('thankyou', thankyou, name = "thankyou"),
    path('pay_on_delivery', pay_on_delivery, name="pay_on_delivery"),
    # path('remove-from-cart/<pk>/', remove_from_cart,name='remove-from-cart')
]          