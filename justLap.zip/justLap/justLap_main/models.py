from django.db import models
from django.core.validators import MinLengthValidator, MaxLengthValidator
from django.conf import settings
# from django.shortcuts import reverse
from django.contrib.auth.models import User
from datetime import datetime
import uuid, random
from django.utils import timezone
from django.urls import reverse

# Create your models here.
CATEGORY = (
    ('p', 'Portability'),
    ('S', 'Size'),
    ('C', 'Color')
)

def generate_pk():
    number = random.randint(1000, 9999)
    return 'AA{}{}'.format(timezone.now().strftime('%y%m%d'), number)

class Product(models.Model):
    product_name = models.CharField(max_length=200)
    price = models.IntegerField()
    discount_price = models.FloatField(default=1.1, blank=False, null=False)
    description = models.TextField()
    image = models.CharField(max_length=6000,null=False, blank=False, default='empty_image.png')
    category = models.CharField(choices=CATEGORY, max_length=2)
    quantity = models.IntegerField(default=1)
    id = models.IntegerField(primary_key=True, default=generate_pk, editable=True, unique=True)
    def __str__(self):
        return self.product_name

class About(models.Model):
    name = models.CharField(max_length=200)
    message = models.TextField()
    user_image = models.ImageField(upload_to="posts", null=True)
    user = models.ForeignKey(User,on_delete=models.CASCADE, null=True, blank=True)
    email = models.CharField(max_length=150, null=False)
    def __str__(self):
        return self.name

class Faq(models.Model):
    question = models.CharField(max_length=200)
    answer = models.CharField(max_length=2000)
    def __str__(self):
        return self.question

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE,null=True, blank=True)
    caption = models.CharField(max_length=200) 
    image = models.ImageField(upload_to='static/justLap_main/images')
    def __str__(self):
        return self.caption

class Store(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE,null=True, blank=True)
    id = models.IntegerField(default=1, primary_key=True, editable=True, unique=True)
    product_image = models.CharField(max_length=6000,null=False, blank=False, default='empty_image.png')
    name = models.CharField(max_length=200)
    product_price = models.IntegerField()
    detail = models.TextField()
    product_discount = models.FloatField(default=1.1, blank=False, null=False)
    product_quantity = models.IntegerField(default=1)
    class Meta:
        unique_together = ["name", "product_price", "product_image", "product_discount", "detail"]
    def __str__(self):
        return self.name
    def get_absolute_url(self):
        return reverse("product_delete_view", args=[self.id])
    
# class OrderItems(models.Model):
#     prod_name = models.CharField(max_length=200)
#     prod_detail = models.TextField()
#     prod_price = models.IntegerField(default=1, blank=False, null=False)
#     prod_discount = models.FloatField(default=1.1, blank=False, null=False)
#     prod_img = models.CharField(max_length=6000,null=False, blank=False, default='empty_image.png')
#     def __str__(self):
#         return self.prod_name
    
class BookedList(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE,null=True, blank=True)
    fname = models.CharField(max_length=150, null=False)
    lname = models.CharField(max_length=150, null=False)
    address = models.TextField(null=False)
    state = models.CharField(max_length=150, null=False)
    email = models.CharField(max_length=150, null=False)
    city = models.CharField(max_length=150, null=False)
    country = models.CharField(max_length=150, null=False)
    pin_code = models.CharField(max_length=150, null=False)
    payment_mode = models.CharField(max_length=150, null=False)
    payment_id = models.CharField(max_length=250, null=True)
    orderstatuses = (
        ('Ordered', 'Ordered'),
        ('Out for shipping', 'Out for shipping'),
        ('Delivered', 'Delivered'),
    )
    status = models.CharField(max_length=150, choices=orderstatuses, default='Ordered')
    message = models.TextField(null=True)
    tracking_no = models.CharField(max_length=150, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def _str_(self):
        return '{} - {}'.format(self.id, self.tracking_no)
    
class Booked(models.Model):
    delivery_fee = models.IntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
    orderstatuses = (
        ('Ordered', 'Ordered'),
        ('Out for shipping', 'Out for shipping'),
        ('Delivered', 'Delivered'),
    )
    status = models.CharField(max_length=150, choices=orderstatuses, default='Ordered')
    user = models.ForeignKey(User,on_delete=models.CASCADE,null=True, blank=True)
    product_image = models.CharField(max_length=6000,null=False, blank=False, default='empty_image.png')
    name = models.CharField(max_length=200)
    product_price = models.IntegerField()
    detail = models.TextField()
    product_discount = models.CharField(max_length=200)
    fname = models.CharField(max_length=150, null=False)
    lname = models.CharField(max_length=150, null=False)
    email = models.CharField(max_length=150, null=False)
    def _str_(self):
        return self.fname
# class OrderItem(models.Model) :
#     user = models.ForeignKey(User,on_delete=models.CASCADE,null=True, blank=True)
#     ordered = models.BooleanField(default=False)
#     item = models.ForeignKey(Product, on_delete=models.CASCADE,blank=True, null=True)
#     quantity = models.IntegerField(default=1)


#     def __str__(self):
#         return f"{self.quantity} of {self.item.product_name}"

# class Order(models.Model):
#     user = models.ForeignKey(User, on_delete=models.CASCADE,null=True, blank=True)
#     items = models.OneToOneField(OrderItem,blank=True, null=True, on_delete=models.CASCADE)
#     start_date = models.DateTimeField(auto_now_add=True)
#     ordered_date = models.DateTimeField()
#     ordered = models.BooleanField(default=False)

#     def __str__(self):
#         return self.user.email
    
# class User(models.Model):
#     roles = models.ManyToManyField(Product.product_name)

# class Cart(models.Model):
#     user = models.ForeignKey(settings.AUTH_USER_MODEL,
#                              on_delete=models.CASCADE)
#     ordered = models.BooleanField(default=False)
#     item = models.ForeignKey(Product, on_delete=models.CASCADE)
#     quantity = models.IntegerField(default=1)
    
#     def __str__(self):
#         return f"{self.quantity} of {self.product.product_name}"
